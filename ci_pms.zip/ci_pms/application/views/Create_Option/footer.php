<!-- /.Footer -->
<!--<footer id="footer" >-->
	<div style="margin-top:7em"></div>
	<footer id="footer" class="navbar navbar-fixed-bottom">
	<p>&copy; CI Pharmacy Sales and Inventory System,  <?php echo date('Y')?>  </p>
	</footer>
	<!-- Bootstrap core JavaScript
    ================================================== -->
	<!-- Placed at the end of the document so the pages load faster -->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
	<script>
		window.jQuery ||
		document.write(
			'<script src="../../assets/js/vendor/jquery.min.js"><\/script>'
		);
	</script>
	<script src="assets/js/bootstrap.min.js"></script>
	</body>
	</html>
